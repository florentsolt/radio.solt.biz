BBC Radio 1xtra Player
======================

How to install:
```shell
$> git clone https://github.com/florentsolt/radio.solt.biz.git
$> cd radio.solt.biz
$> npm install
$> grunt
```

Then inspect the folder `build`, run the app, ENJOY!
